# Bitaraka Production mobile

Application mobile de suivi de fabrication pour Bitaraka Industrie.

## Règles intégrées

- Petits : coller les rondelles, percer, coller les posters, gratter les posters.
- Moyens, Gros et Plus gros : coller les rondelles, gratter les rondelles, percer, coller les posters, gratter les posters.
- Tarif initial : 20 FCFA par coffre et par opération, modifiable par l’administrateur.
- Une tirelire finalisée correspond au minimum validé entre toutes les étapes obligatoires de sa taille.

## Android

Projet natif Java dans `android/`. Les données sont conservées localement sur le téléphone. Code administrateur initial : `2026`.

## iOS

Sources SwiftUI dans `ios/BitarakaProduction/`. Une signature Apple est nécessaire pour produire un IPA et l’installer via TestFlight ou l’App Store.

## Compilation Android

Le workflow GitHub Actions compile une APK de test Android standard avec Gradle,
exécute Android Lint et vérifie sa signature avec apksigner.
Télécharger l'artefact Bitaraka-Production-APK après une exécution réussie.
Cette préparation des sources ne signifie pas que la compilation a réussi.

La clé de développement et local.properties ne sont pas publiés. Android génère
une signature debug dans l'environnement de compilation. Cette clé peut changer
entre les compilations : ne pas désinstaller une application contenant des données
sans les conserver. Une signature stable privée sera nécessaire pour les mises à jour
et la distribution de production.
