package ga.bitaraka.production;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    private static final int NAVY = Color.rgb(6, 43, 102);
    private static final int GOLD = Color.rgb(224, 172, 34);
    private static final int BG = Color.rgb(243, 246, 251);
    private static final String[] SIZE_CODES = {"PETIT", "MOYEN", "GROS", "PLUS_GROS"};
    private static final String[] SIZE_LABELS = {"Petits", "Moyens", "Gros", "Plus gros"};
    private static final String[] TASK_CODES = {"COLLER_RONDELLES", "GRATTER_RONDELLES", "PERCER", "COLLER_POSTERS", "GRATTER_POSTERS"};
    private static final String[] TASK_LABELS = {"Coller les rondelles", "Gratter les rondelles", "Percer", "Coller les posters", "Gratter les posters"};

    private SharedPreferences prefs;
    private LinearLayout content;
    private Spinner sizeSpinner, taskSpinner;
    private EditText workerName, quantity;
    private TextView amountPreview;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        prefs = getSharedPreferences("bitaraka_production", MODE_PRIVATE);
        seedRates();
        showHome();
    }

    private void showHome() {
        ScrollView scroll = baseScreen();
        addBrandHeader(false);
        TextView title = title("Gestion de la production", 27);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(18), dp(28), dp(18), dp(8));
        content.addView(title);
        TextView intro = text("Suivez les coffres fabriqués, les opérations des travailleurs et les montants à payer.", 15, Color.DKGRAY);
        intro.setGravity(Gravity.CENTER); intro.setPadding(dp(28), 0, dp(28), dp(28)); content.addView(intro);

        Button worker = primaryButton("ESPACE TRAVAILLEUR");
        worker.setOnClickListener(v -> showWorker()); content.addView(worker, marginParams(20, 8));
        Button admin = outlineButton("ESPACE ADMINISTRATEUR");
        admin.setOnClickListener(v -> askAdminPin()); content.addView(admin, marginParams(20, 12));
        TextView note = text("Tarif initial : 20 FCFA par coffre et par opération. Les données restent enregistrées dans le téléphone.", 13, Color.GRAY);
        note.setGravity(Gravity.CENTER); note.setPadding(dp(28), dp(20), dp(28), dp(32)); content.addView(note);
        setContentView(scroll);
    }

    private void askAdminPin() {
        EditText pin = new EditText(this); pin.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_VARIATION_PASSWORD); pin.setHint("Code administrateur");
        int pad = dp(24); pin.setPadding(pad, dp(10), pad, dp(10));
        new AlertDialog.Builder(this).setTitle("Accès administrateur").setMessage("Code initial : 2026").setView(pin)
            .setNegativeButton("Annuler", null).setPositiveButton("Ouvrir", (d, w) -> {
                if (pin.getText().toString().equals(prefs.getString("admin_pin", "2026"))) showAdmin();
                else toast("Code incorrect");
            }).show();
    }

    private void showWorker() {
        ScrollView scroll = baseScreen(); addBrandHeader(true);
        content.addView(sectionTitle("Nouvelle opération", "Déclarez uniquement le travail réellement effectué."));

        workerName = input("Nom du travailleur", InputType.TYPE_CLASS_TEXT);
        workerName.setText(prefs.getString("last_worker", "")); content.addView(labeled("Travailleur", workerName));
        sizeSpinner = spinner(SIZE_LABELS); content.addView(labeled("Taille du coffre", sizeSpinner));
        taskSpinner = spinner(tasksForSize(0)); content.addView(labeled("Étape réalisée", taskSpinner));
        sizeSpinner.setOnItemSelectedListener(new SimpleSelection() { public void selected(int p) { updateTaskSpinner(p); updatePreview(); }});
        taskSpinner.setOnItemSelectedListener(new SimpleSelection() { public void selected(int p) { updatePreview(); }});
        quantity = input("Ex. 50", InputType.TYPE_CLASS_NUMBER); quantity.setTextSize(22); content.addView(labeled("Nombre de coffres", quantity));
        quantity.setOnFocusChangeListener((v, has) -> { if (!has) updatePreview(); });

        amountPreview = text("Gain calculé : 0 FCFA", 20, NAVY); amountPreview.setTypeface(Typeface.DEFAULT, Typeface.BOLD); amountPreview.setGravity(Gravity.CENTER); amountPreview.setBackgroundColor(Color.rgb(255, 248, 223)); amountPreview.setPadding(dp(12), dp(18), dp(12), dp(18)); content.addView(amountPreview, marginParams(20, 14));
        Button calculate = outlineButton("CALCULER"); calculate.setOnClickListener(v -> updatePreview()); content.addView(calculate, marginParams(20, 6));
        Button save = primaryButton("ENREGISTRER L’OPÉRATION"); save.setOnClickListener(v -> saveEntry()); content.addView(save, marginParams(20, 10));
        content.addView(workerRecent());
        setContentView(scroll);
    }

    private void saveEntry() {
        String name = workerName.getText().toString().trim();
        int qty = intValue(quantity.getText().toString());
        if (name.length() < 2) { toast("Entrez le nom du travailleur"); return; }
        if (qty < 1) { toast("Entrez une quantité valide"); return; }
        int s = sizeSpinner.getSelectedItemPosition();
        int taskIndex = taskIndexesForSize(s)[taskSpinner.getSelectedItemPosition()];
        int rate = rate(SIZE_CODES[s], TASK_CODES[taskIndex]);
        try {
            JSONArray entries = entries(); JSONObject e = new JSONObject();
            e.put("id", UUID.randomUUID().toString()); e.put("worker", name); e.put("size", SIZE_CODES[s]); e.put("task", TASK_CODES[taskIndex]);
            e.put("quantity", qty); e.put("rate", rate); e.put("amount", qty * rate); e.put("date", today()); e.put("status", "pending"); e.put("createdAt", System.currentTimeMillis());
            entries.put(e); saveEntries(entries); prefs.edit().putString("last_worker", name).apply();
            quantity.setText(""); updatePreview(); toast("Opération enregistrée et envoyée à la validation");
        } catch (Exception ex) { toast("Enregistrement impossible"); }
    }

    private View workerRecent() {
        LinearLayout box = card(); box.addView(title("Mes dernières déclarations", 19));
        String current = prefs.getString("last_worker", ""); int count = 0;
        JSONArray all = entries();
        for (int i = all.length() - 1; i >= 0 && count < 8; i--) try {
            JSONObject e = all.getJSONObject(i); if (!current.equals(e.optString("worker"))) continue;
            box.addView(entryView(e, false)); count++;
        } catch (Exception ignored) {}
        if (count == 0) box.addView(text("Aucune déclaration enregistrée.", 14, Color.GRAY));
        return box;
    }

    private void showAdmin() {
        ScrollView scroll = baseScreen(); addBrandHeader(true);
        content.addView(sectionTitle("Tableau de bord", "Contrôle, validation et calcul de la production."));
        LinearLayout actions = new LinearLayout(this); actions.setOrientation(LinearLayout.HORIZONTAL); actions.setPadding(dp(14), 0, dp(14), dp(8));
        Button export = smallButton("PARTAGER LE RAPPORT"); export.setOnClickListener(v -> shareReport()); actions.addView(export, new LinearLayout.LayoutParams(0, dp(48), 1));
        Button rates = smallButton("TARIFS"); rates.setOnClickListener(v -> showRates()); LinearLayout.LayoutParams rp = new LinearLayout.LayoutParams(0, dp(48), 0.55f); rp.setMargins(dp(8),0,0,0); actions.addView(rates, rp); content.addView(actions);
        content.addView(summaryCard());
        content.addView(pendingCard());
        content.addView(historyCard());
        setContentView(scroll);
    }

    private View summaryCard() {
        LinearLayout box = card(); box.addView(title("Production finalisée aujourd’hui", 20));
        TextView help = text("Une tirelire est finalisée seulement lorsque toutes ses étapes sont validées.", 13, Color.GRAY); help.setPadding(0,0,0,dp(10)); box.addView(help);
        for (int s = 0; s < SIZE_CODES.length; s++) {
            LinearLayout row = row(); row.addView(text(SIZE_LABELS[s], 16, Color.DKGRAY), new LinearLayout.LayoutParams(0, dp(48), 1));
            TextView value = badge(String.valueOf(finalizedCount(SIZE_CODES[s], today()))); row.addView(value); box.addView(row);
        }
        int totalPay = 0, pending = 0; Set<String> workers = new HashSet<>(); JSONArray all = entries();
        for (int i=0;i<all.length();i++) try { JSONObject e=all.getJSONObject(i); workers.add(e.optString("worker")); if ("approved".equals(e.optString("status"))) totalPay += e.optInt("amount"); if ("pending".equals(e.optString("status"))) pending++; } catch(Exception ignored){}
        TextView stats = text("Main-d’œuvre validée : " + money(totalPay) + "\nEn attente : " + pending + " opération(s)\nTravailleurs : " + workers.size(), 15, NAVY); stats.setTypeface(Typeface.DEFAULT, Typeface.BOLD); stats.setPadding(0, dp(14), 0, dp(4)); box.addView(stats);
        return box;
    }

    private View pendingCard() {
        LinearLayout box = card(); box.addView(title("Validations en attente", 20)); int count=0; JSONArray all=entries();
        for (int i=all.length()-1;i>=0;i--) try { JSONObject e=all.getJSONObject(i); if (!"pending".equals(e.optString("status"))) continue; count++;
            LinearLayout item = new LinearLayout(this); item.setOrientation(LinearLayout.VERTICAL); item.setPadding(0,dp(8),0,dp(12)); item.addView(entryView(e,true));
            LinearLayout buttons=row(); Button reject=rejectButton("REFUSER"); final String id=e.optString("id"); reject.setOnClickListener(v -> updateStatus(id,"rejected")); Button approve=approveButton("VALIDER"); approve.setOnClickListener(v -> updateStatus(id,"approved")); buttons.addView(reject,new LinearLayout.LayoutParams(0,dp(44),1)); LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,dp(44),1); ap.setMargins(dp(8),0,0,0); buttons.addView(approve,ap); item.addView(buttons); box.addView(item);
        } catch(Exception ignored){}
        if(count==0) box.addView(text("Tout est à jour.",15,Color.rgb(20,120,70)));
        return box;
    }

    private View historyCard() {
        LinearLayout box=card(); box.addView(title("Historique récent",20)); JSONArray all=entries(); int shown=0;
        for(int i=all.length()-1;i>=0 && shown<30;i--) try{box.addView(entryView(all.getJSONObject(i),true)); shown++;}catch(Exception ignored){}
        if(shown==0) box.addView(text("Aucune donnée.",14,Color.GRAY)); return box;
    }

    private void updateStatus(String id, String status) {
        JSONArray all=entries();
        for(int i=0;i<all.length();i++) try{JSONObject e=all.getJSONObject(i); if(id.equals(e.optString("id"))){e.put("status",status);e.put("validatedAt",System.currentTimeMillis());break;}}catch(Exception ignored){}
        saveEntries(all); toast("approved".equals(status)?"Opération validée":"Opération refusée"); showAdmin();
    }

    private void showRates() {
        ScrollView scroll=baseScreen(); addBrandHeader(true); content.addView(sectionTitle("Tarifs", "Montant en FCFA par coffre et par opération."));
        Map<String,EditText> fields=new LinkedHashMap<>();
        for(int s=0;s<SIZE_CODES.length;s++){
            LinearLayout box=card(); box.addView(title(SIZE_LABELS[s],20)); int[] indexes=taskIndexesForSize(s);
            for(int idx:indexes){String key=SIZE_CODES[s]+"_"+TASK_CODES[idx]; EditText input=input("20",InputType.TYPE_CLASS_NUMBER); input.setText(String.valueOf(rate(SIZE_CODES[s],TASK_CODES[idx]))); fields.put(key,input); box.addView(labeled(TASK_LABELS[idx],input));} content.addView(box);
        }
        Button save=primaryButton("ENREGISTRER LES TARIFS"); save.setOnClickListener(v->{SharedPreferences.Editor ed=prefs.edit(); for(Map.Entry<String,EditText> f:fields.entrySet()) ed.putInt("rate_"+f.getKey(),Math.max(0,intValue(f.getValue().getText().toString()))); ed.apply(); toast("Tarifs mis à jour"); showAdmin();}); content.addView(save,marginParams(20,12)); setContentView(scroll);
    }

    private void shareReport() {
        StringBuilder report=new StringBuilder("BITARAKA INDUSTRIE - RAPPORT DE PRODUCTION\nDate : ").append(today()).append("\n\n");
        for(int s=0;s<SIZE_CODES.length;s++) report.append(SIZE_LABELS[s]).append(" finalisés : ").append(finalizedCount(SIZE_CODES[s],today())).append("\n");
        report.append("\nDÉTAIL DES OPÉRATIONS\n"); JSONArray all=entries();
        for(int i=0;i<all.length();i++) try{JSONObject e=all.getJSONObject(i); report.append(e.optString("worker")).append(" | ").append(sizeLabel(e.optString("size"))).append(" | ").append(taskLabel(e.optString("task"))).append(" | ").append(e.optInt("quantity")).append(" | ").append(money(e.optInt("amount"))).append(" | ").append(statusLabel(e.optString("status"))).append("\n");}catch(Exception ignored){}
        Intent send=new Intent(Intent.ACTION_SEND); send.setType("text/plain"); send.putExtra(Intent.EXTRA_SUBJECT,"Rapport Bitaraka Production"); send.putExtra(Intent.EXTRA_TEXT,report.toString()); startActivity(Intent.createChooser(send,"Partager le rapport"));
    }

    private int finalizedCount(String size, String date) {
        List<String> required=new ArrayList<>(); for(int idx:taskIndexesForSize(indexOf(SIZE_CODES,size))) required.add(TASK_CODES[idx]);
        int min=Integer.MAX_VALUE; JSONArray all=entries();
        for(String task:required){int sum=0; for(int i=0;i<all.length();i++) try{JSONObject e=all.getJSONObject(i); if("approved".equals(e.optString("status"))&&size.equals(e.optString("size"))&&task.equals(e.optString("task"))&&date.equals(e.optString("date"))) sum+=e.optInt("quantity");}catch(Exception ignored){} min=Math.min(min,sum);} return min==Integer.MAX_VALUE?0:min;
    }

    private void updatePreview() {
        if(sizeSpinner==null||taskSpinner==null||quantity==null||amountPreview==null)return; int s=sizeSpinner.getSelectedItemPosition(); int[] indexes=taskIndexesForSize(s); int pos=Math.max(0,taskSpinner.getSelectedItemPosition()); if(pos>=indexes.length)pos=0; int qty=intValue(quantity.getText().toString()); int amount=qty*rate(SIZE_CODES[s],TASK_CODES[indexes[pos]]); amountPreview.setText("Gain calculé : "+money(amount));
    }

    private void updateTaskSpinner(int sizePosition) { taskSpinner.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,tasksForSize(sizePosition))); }
    private String[] tasksForSize(int sizePosition){int[] idx=taskIndexesForSize(sizePosition);String[] labels=new String[idx.length];for(int i=0;i<idx.length;i++)labels[i]=TASK_LABELS[idx[i]];return labels;}
    private int[] taskIndexesForSize(int sizePosition){return sizePosition==0?new int[]{0,2,3,4}:new int[]{0,1,2,3,4};}
    private int rate(String size,String task){return prefs.getInt("rate_"+size+"_"+task,20);}
    private void seedRates(){if(!prefs.contains("seeded")){SharedPreferences.Editor e=prefs.edit();for(String s:SIZE_CODES)for(String t:TASK_CODES)e.putInt("rate_"+s+"_"+t,20);e.putBoolean("seeded",true).apply();}}
    private JSONArray entries(){try{return new JSONArray(prefs.getString("entries","[]"));}catch(Exception e){return new JSONArray();}}
    private void saveEntries(JSONArray a){prefs.edit().putString("entries",a.toString()).apply();}
    private String today(){return new SimpleDateFormat("yyyy-MM-dd",Locale.FRANCE).format(new Date());}
    private String money(int n){return NumberFormat.getIntegerInstance(Locale.FRANCE).format(n)+" FCFA";}
    private int intValue(String s){try{return Integer.parseInt(s.trim());}catch(Exception e){return 0;}}
    private int indexOf(String[] a,String value){for(int i=0;i<a.length;i++)if(a[i].equals(value))return i;return 0;}
    private String sizeLabel(String code){return SIZE_LABELS[indexOf(SIZE_CODES,code)];}
    private String taskLabel(String code){return TASK_LABELS[indexOf(TASK_CODES,code)];}
    private String statusLabel(String s){return "approved".equals(s)?"Validé":"rejected".equals(s)?"Refusé":"En attente";}

    private ScrollView baseScreen(){getWindow().setStatusBarColor(NAVY);ScrollView s=new ScrollView(this);s.setFillViewport(true);s.setBackgroundColor(BG);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,0,0,dp(36));s.addView(content,new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT));return s;}
    private void addBrandHeader(boolean back){LinearLayout h=new LinearLayout(this);h.setGravity(Gravity.CENTER_VERTICAL);h.setPadding(dp(14),dp(12),dp(14),dp(12));h.setBackgroundColor(NAVY);if(back){Button b=new Button(this);b.setText("‹");b.setTextSize(28);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.TRANSPARENT);b.setOnClickListener(v->showHome());h.addView(b,new LinearLayout.LayoutParams(dp(48),dp(54)));}ImageView logo=new ImageView(this);logo.setImageResource(ga.bitaraka.production.R.drawable.bitaraka_logo);logo.setScaleType(ImageView.ScaleType.CENTER_INSIDE);h.addView(logo,new LinearLayout.LayoutParams(dp(64),dp(64)));LinearLayout names=new LinearLayout(this);names.setOrientation(LinearLayout.VERTICAL);TextView brand=text("BITARAKA INDUSTRIE",18,Color.WHITE);brand.setTypeface(Typeface.DEFAULT,Typeface.BOLD);names.addView(brand);names.addView(text("Production & travailleurs",12,Color.rgb(205,222,245)));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(0,ViewGroup.LayoutParams.WRAP_CONTENT,1);np.setMargins(dp(10),0,0,0);h.addView(names,np);content.addView(h);}
    private LinearLayout sectionTitle(String t,String sub){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(20),dp(24),dp(20),dp(10));b.addView(title(t,24));b.addView(text(sub,14,Color.GRAY));return b;}
    private LinearLayout card(){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(18),dp(18),dp(18),dp(18));b.setBackgroundColor(Color.WHITE);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(dp(14),dp(8),dp(14),dp(8));b.setLayoutParams(p);return b;}
    private LinearLayout row(){LinearLayout r=new LinearLayout(this);r.setOrientation(LinearLayout.HORIZONTAL);r.setGravity(Gravity.CENTER_VERTICAL);return r;}
    private TextView title(String s,int size){TextView t=text(s,size,NAVY);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    private TextView text(String s,int size,int color){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);t.setLineSpacing(0,1.12f);return t;}
    private TextView badge(String s){TextView t=text(s,18,Color.WHITE);t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);t.setGravity(Gravity.CENTER);t.setBackgroundColor(NAVY);t.setPadding(dp(14),dp(6),dp(14),dp(6));return t;}
    private EditText input(String hint,int type){EditText e=new EditText(this);e.setHint(hint);e.setInputType(type);e.setTextColor(Color.DKGRAY);e.setHintTextColor(Color.LTGRAY);e.setBackgroundColor(Color.rgb(247,249,252));e.setPadding(dp(14),dp(10),dp(14),dp(10));return e;}
    private Spinner spinner(String[] values){Spinner s=new Spinner(this);s.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,values));s.setBackgroundColor(Color.rgb(247,249,252));s.setPadding(dp(10),0,dp(10),0);return s;}
    private LinearLayout labeled(String label,View field){LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(dp(20),dp(7),dp(20),dp(7));TextView l=text(label,14,Color.DKGRAY);l.setTypeface(Typeface.DEFAULT,Typeface.BOLD);l.setPadding(0,0,0,dp(6));b.addView(l);b.addView(field,new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(54)));return b;}
    private Button primaryButton(String s){Button b=new Button(this);b.setText(s);b.setTextColor(NAVY);b.setTextSize(15);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackgroundColor(GOLD);return b;}
    private Button outlineButton(String s){Button b=primaryButton(s);b.setTextColor(Color.WHITE);b.setBackgroundColor(NAVY);return b;}
    private Button smallButton(String s){Button b=outlineButton(s);b.setTextSize(12);return b;}
    private Button approveButton(String s){Button b=primaryButton(s);b.setTextColor(Color.WHITE);b.setBackgroundColor(Color.rgb(22,145,87));return b;}
    private Button rejectButton(String s){Button b=primaryButton(s);b.setTextColor(Color.rgb(180,30,45));b.setBackgroundColor(Color.rgb(255,232,235));return b;}
    private LinearLayout.LayoutParams marginParams(int horizontal,int vertical){LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,dp(56));p.setMargins(dp(horizontal),dp(vertical),dp(horizontal),dp(vertical));return p;}
    private View entryView(JSONObject e,boolean showWorker){LinearLayout row=new LinearLayout(this);row.setOrientation(LinearLayout.VERTICAL);row.setPadding(dp(12),dp(10),dp(12),dp(10));row.setBackgroundColor(Color.rgb(247,249,252));String top=(showWorker?e.optString("worker")+" · ":"")+taskLabel(e.optString("task"))+" · "+sizeLabel(e.optString("size"));TextView a=text(top,14,Color.DKGRAY);a.setTypeface(Typeface.DEFAULT,Typeface.BOLD);row.addView(a);row.addView(text(e.optInt("quantity")+" × "+e.optInt("rate")+" F = "+money(e.optInt("amount"))+" · "+statusLabel(e.optString("status")),12,"rejected".equals(e.optString("status"))?Color.RED:"approved".equals(e.optString("status"))?Color.rgb(20,120,70):Color.rgb(170,110,0)));LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);p.setMargins(0,dp(4),0,dp(4));row.setLayoutParams(p);return row;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    @Override public void onBackPressed(){showHome();}

    private abstract class SimpleSelection implements AdapterView.OnItemSelectedListener { public abstract void selected(int p); public void onItemSelected(AdapterView<?> p,View v,int pos,long id){selected(pos);} public void onNothingSelected(AdapterView<?> p){} }
}
