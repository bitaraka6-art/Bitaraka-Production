import SwiftUI

@main
struct BitarakaProductionApp: App {
    @StateObject private var store = ProductionStore()

    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(store)
        }
    }
}
