import SwiftUI

private let navy = Color(red: 6/255, green: 43/255, blue: 102/255)
private let gold = Color(red: 224/255, green: 172/255, blue: 34/255)

struct ContentView: View {
    @State private var mode: Mode = .home
    enum Mode { case home, worker, admin }

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                BrandHeader()
                switch mode {
                case .home: HomeView(worker: { mode = .worker }, admin: { mode = .admin })
                case .worker: WorkerView(back: { mode = .home })
                case .admin: AdminView(back: { mode = .home })
                }
            }.background(Color(.systemGroupedBackground)).toolbar(.hidden, for: .navigationBar)
        }
    }
}

struct BrandHeader: View {
    var body: some View {
        HStack(spacing: 12) {
            Image("Logo").resizable().scaledToFit().frame(width: 58, height: 58).background(.white).clipShape(RoundedRectangle(cornerRadius: 14))
            VStack(alignment: .leading) { Text("BITARAKA INDUSTRIE").font(.headline).bold(); Text("Production & travailleurs").font(.caption).foregroundStyle(Color.white.opacity(0.78)) }
            Spacer()
        }.foregroundStyle(.white).padding().background(navy)
    }
}

struct HomeView: View {
    let worker: () -> Void; let admin: () -> Void
    var body: some View {
        VStack(spacing: 20) {
            Spacer(); Text("Gestion de la production").font(.largeTitle).bold().foregroundStyle(navy).multilineTextAlignment(.center)
            Text("Suivez les coffres fabriqués, le travail effectué et les montants à payer.").multilineTextAlignment(.center).foregroundStyle(.secondary)
            Button("ESPACE TRAVAILLEUR", action: worker).buttonStyle(GoldButton())
            Button("ESPACE ADMINISTRATEUR", action: admin).buttonStyle(NavyButton())
            Spacer()
        }.padding(24)
    }
}

struct WorkerView: View {
    @EnvironmentObject var store: ProductionStore
    let back: () -> Void
    @State private var worker = ""; @State private var size = CoffreSize.petit; @State private var task = ProductionTask.collerRondelles; @State private var quantity = ""
    var amount: Int { (Int(quantity) ?? 0) * store.rate(size, task) }

    var body: some View {
        Form {
            Button("‹ Retour", action: back).foregroundStyle(navy)
            Section("Nouvelle opération") {
                TextField("Nom du travailleur", text: $worker)
                Picker("Taille", selection: $size) { ForEach(CoffreSize.allCases) { Text($0.label).tag($0) } }.onChange(of: size) { _, value in task = requiredTasks(for: value).first! }
                Picker("Étape", selection: $task) { ForEach(requiredTasks(for: size)) { Text($0.label).tag($0) } }
                TextField("Nombre de coffres", text: $quantity).keyboardType(.numberPad)
                HStack { Text("Gain calculé"); Spacer(); Text("\(amount) FCFA").bold().foregroundStyle(navy) }
                Button("Enregistrer") { if let count = Int(quantity), count > 0, worker.count > 1 { store.add(worker: worker, size: size, task: task, quantity: count); quantity = "" } }.buttonStyle(GoldButton())
            }
            Section("Dernières déclarations") { ForEach(store.entries.prefix(10)) { EntryLine(entry: $0) } }
        }
    }
}

struct AdminView: View {
    @EnvironmentObject var store: ProductionStore
    let back: () -> Void
    var pending: [ProductionEntry] { store.entries.filter { $0.status == .pending } }
    var body: some View {
        List {
            Button("‹ Retour", action: back).foregroundStyle(navy)
            Section("Production finalisée aujourd’hui") { ForEach(CoffreSize.allCases) { size in HStack { Text(size.label); Spacer(); Text("\(store.finalized(size))").bold().padding(.horizontal, 12).padding(.vertical, 6).background(navy).foregroundStyle(.white).clipShape(RoundedRectangle(cornerRadius: 10)) } } }
            Section("Validations en attente") {
                if pending.isEmpty { Text("Tout est à jour.").foregroundStyle(.green) }
                ForEach(pending) { entry in VStack(alignment: .leading, spacing: 8) { EntryLine(entry: entry); HStack { Button("Refuser") { store.validate(entry.id, status: .rejected) }.tint(.red); Spacer(); Button("Valider") { store.validate(entry.id, status: .approved) }.tint(.green) } }.buttonStyle(.bordered) }
            }
            Section("Historique") { ForEach(store.entries.prefix(40)) { EntryLine(entry: $0) } }
        }
    }
}

struct EntryLine: View {
    let entry: ProductionEntry
    var body: some View { VStack(alignment: .leading) { Text("\(entry.worker) · \(entry.task.label) · \(entry.size.label)").bold(); Text("\(entry.quantity) × \(entry.rate) F = \(entry.amount) FCFA · \(entry.status == .approved ? "Validé" : entry.status == .rejected ? "Refusé" : "En attente")").font(.caption).foregroundStyle(.secondary) } }
}

struct GoldButton: ButtonStyle { func makeBody(configuration: Configuration) -> some View { configuration.label.frame(maxWidth: .infinity).padding().background(gold.opacity(configuration.isPressed ? 0.7 : 1)).foregroundStyle(navy).bold().clipShape(RoundedRectangle(cornerRadius: 14)) } }
struct NavyButton: ButtonStyle { func makeBody(configuration: Configuration) -> some View { configuration.label.frame(maxWidth: .infinity).padding().background(navy.opacity(configuration.isPressed ? 0.7 : 1)).foregroundStyle(.white).bold().clipShape(RoundedRectangle(cornerRadius: 14)) } }
