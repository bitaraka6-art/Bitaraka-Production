import Foundation

enum CoffreSize: String, Codable, CaseIterable, Identifiable {
    case petit, moyen, gros, plusGros
    var id: String { rawValue }
    var label: String { switch self { case .petit: "Petits"; case .moyen: "Moyens"; case .gros: "Gros"; case .plusGros: "Plus gros" } }
}

enum ProductionTask: String, Codable, CaseIterable, Identifiable {
    case collerRondelles, gratterRondelles, percer, collerPosters, gratterPosters
    var id: String { rawValue }
    var label: String { switch self { case .collerRondelles: "Coller les rondelles"; case .gratterRondelles: "Gratter les rondelles"; case .percer: "Percer"; case .collerPosters: "Coller les posters"; case .gratterPosters: "Gratter les posters" } }
}

enum EntryStatus: String, Codable { case pending, approved, rejected }

struct ProductionEntry: Identifiable, Codable {
    var id = UUID()
    let worker: String
    let size: CoffreSize
    let task: ProductionTask
    let quantity: Int
    let rate: Int
    let date: Date
    var status: EntryStatus = .pending
    var amount: Int { quantity * rate }
}

func requiredTasks(for size: CoffreSize) -> [ProductionTask] {
    size == .petit
      ? [.collerRondelles, .percer, .collerPosters, .gratterPosters]
      : [.collerRondelles, .gratterRondelles, .percer, .collerPosters, .gratterPosters]
}
