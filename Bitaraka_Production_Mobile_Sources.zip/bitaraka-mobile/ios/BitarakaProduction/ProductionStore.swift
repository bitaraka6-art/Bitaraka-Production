import Foundation

final class ProductionStore: ObservableObject {
    @Published var entries: [ProductionEntry] = [] { didSet { save() } }
    @Published var rates: [String: Int] = [:] { didSet { saveRates() } }

    init() {
        if let data = UserDefaults.standard.data(forKey: "entries"), let saved = try? JSONDecoder().decode([ProductionEntry].self, from: data) { entries = saved }
        if let saved = UserDefaults.standard.dictionary(forKey: "rates") as? [String: Int] { rates = saved }
    }

    func key(_ size: CoffreSize, _ task: ProductionTask) -> String { "\(size.rawValue)_\(task.rawValue)" }
    func rate(_ size: CoffreSize, _ task: ProductionTask) -> Int { rates[key(size, task)] ?? 20 }
    func setRate(_ amount: Int, size: CoffreSize, task: ProductionTask) { rates[key(size, task)] = max(0, amount) }
    func add(worker: String, size: CoffreSize, task: ProductionTask, quantity: Int) { entries.insert(.init(worker: worker, size: size, task: task, quantity: quantity, rate: rate(size, task), date: Date()), at: 0) }
    func validate(_ id: UUID, status: EntryStatus) { if let index = entries.firstIndex(where: { $0.id == id }) { entries[index].status = status } }

    func finalized(_ size: CoffreSize) -> Int {
        let calendar = Calendar.current
        return requiredTasks(for: size).map { task in
            entries.filter { $0.size == size && $0.task == task && $0.status == .approved && calendar.isDateInToday($0.date) }.reduce(0) { $0 + $1.quantity }
        }.min() ?? 0
    }

    private func save() { if let data = try? JSONEncoder().encode(entries) { UserDefaults.standard.set(data, forKey: "entries") } }
    private func saveRates() { UserDefaults.standard.set(rates, forKey: "rates") }
}
